(()=>{'use strict';
const API=location.pathname.replace(/\/(ca|es|en)\/[^\/]*$/,''),$=id=>document.getElementById(id);
const session=new URLSearchParams(location.search).get('session_id');let credential=new URLSearchParams(location.hash.slice(1)).get('token');
try{if(credential&&session)sessionStorage.setItem('orsini-result:'+session,credential);else if(session)credential=sessionStorage.getItem('orsini-result:'+session)}catch{}
if(location.hash)history.replaceState(null,'',location.pathname+location.search);
let tries=0,timer=null,busy=false,copy={};
fetch('content/matricula.json').then(r=>r.ok?r.json():{}).then(d=>copy=d).catch(()=>{});
function message(title,body){$('result-title').textContent=title;$('result-message').textContent=body}
function details(d){const list=$('result-details');list.replaceChildren();for(const [label,value]of [['Course',d.course],['Test amount',new Intl.NumberFormat(({ca:'ca-ES',es:'es-ES',en:'en-GB'}[document.documentElement.lang]||'ca-ES'),{style:'currency',currency:'EUR'}).format(d.amount_cents/100)],['Dates',d.schedule],['Format and venue',d.location]]){const block=document.createElement('div'),dt=document.createElement('dt'),dd=document.createElement('dd');dt.textContent=label;dd.textContent=value||'To be confirmed';block.append(dt,dd);list.append(block)}list.hidden=false;$('result-reference').textContent='Reference: '+d.reference}
async function check(){if(busy)return;busy=true;$('result-refresh').disabled=true;clearTimeout(timer);
 if(!session||!credential){message('Check your receipt.','We do not have the credential needed to check this registration. Keep your Stripe receipt and contact us if you need to confirm its status.');busy=false;return}
 try{const r=await fetch(API+'/api/status',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({session_id:session,token:credential}),signal:AbortSignal.timeout(10000)});const d=await r.json();if(!r.ok)throw Error(d.error||'Not available');details(d);
 if(d.status==='paid'){message('Test registration confirmed.',copy.success_message||'We have verified the test payment. It does not correspond to a real place.');$('result-book').hidden=false;$('result-book').textContent=(d.book?'The book “'+d.book+'” is included in the registration. ':'')+'We will give you the gift book at the first session.';$('result-email').textContent=d.email_status==='sent'?'We have sent the test confirmation email. Please also check your spam folder.':d.email_status==='review'?'The email needs to be checked before sending. The registration is recorded as paid in the test environment.':'The confirmation email has not been sent yet. Please keep this registration reference.';$('result-refresh').hidden=d.email_status==='sent';}
 else if(d.status==='review'){message('We are reviewing your registration.','The payment needs to be checked by the team. Your place is not confirmed yet. There is no need to pay again; contact Orsini quoting your reference.');$('result-refresh').hidden=false;}
 else if(d.status==='expired'){message('Your registration is not confirmed.','The payment session expired or was not completed. You can start again from the course page.');$('result-refresh').hidden=true;}
 else{message(d.status==='processing'?'Your payment is being processed.':'Checking your payment.',copy.pending_message||'We are still checking the payment. There is no need to pay again.');$('result-refresh').hidden=false;if(++tries<10)timer=setTimeout(check,2000)}
 }catch{message('We cannot confirm your registration yet.','We could not check the status. If you completed the payment, keep your Stripe receipt and check again in a few moments. There is no need to repeat the payment.');$('result-refresh').hidden=false}
 finally{busy=false;$('result-refresh').disabled=false}
}
$('result-refresh').addEventListener('click',()=>{tries=0;check()});check();
})();
